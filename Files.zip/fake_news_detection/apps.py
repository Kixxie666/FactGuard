from django.apps import AppConfig


class FakeNewsDetectionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fake_news_detection'
